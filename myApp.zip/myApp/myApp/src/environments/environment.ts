
export const environment = {
  production: false,
  ApiUrl:"http://tweetapp-env.eba-byxfyxhe.us-west-1.elasticbeanstalk.com/api/v1.0/tweets"
  //ApiUrl: "http://nkdeploy-env.eba-ebajsaxc.ap-northeast-1.elasticbeanstalk.com/api/v1.0/tweets"
};


