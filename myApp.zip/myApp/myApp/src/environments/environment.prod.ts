export const environment = {
  production: true,
  ApiUrl: 'http://tweetapp-env.eba-byxfyxhe.us-west-1.elasticbeanstalk.com/api/v1.0/tweets'
};
