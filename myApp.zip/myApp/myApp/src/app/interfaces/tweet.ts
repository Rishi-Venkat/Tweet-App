import { User } from './user';

export interface Tweet {
  id: any;
  tweetName:any;
  postDate: any;
  likes: any;
  user: any;
  replies: any;
  tweetTag: any;
}