export interface User {
  id: any;
  username: any;
  password: any;
  email: any;
  firstName: any;
  lastName: any
  contactNumber: any;
}
