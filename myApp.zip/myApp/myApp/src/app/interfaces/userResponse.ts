import { User } from "./user";

export interface userResponse{
    user:String;
    loginStatus:any;
    token?:any;
}