import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reply-tweet',
  templateUrl: './reply-tweet.component.html',
  styleUrls: ['./reply-tweet.component.css']
})
export class ReplyTweetComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
