import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { TweetService } from '../services/tweet.service';

import { EditTweetComponent } from './edit-tweet.component';

describe('EditTweetComponent', () => {
  let component: EditTweetComponent;
  let fixture: ComponentFixture<EditTweetComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports:[HttpClientTestingModule],
      declarations: [ EditTweetComponent ],
      providers:[ AuthService,FormBuilder,TweetService]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EditTweetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  xit('should create', () => {
    expect(component).toBeTruthy();
  });
});
